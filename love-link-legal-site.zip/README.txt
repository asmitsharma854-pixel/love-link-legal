LOVE LINK LEGAL WEBSITE — PUBLISHING GUIDE

Files:
- index.html       Home page
- terms.html       Terms of Service
- privacy.html     Privacy Policy
- style.css        Styling

IMPORTANT BEFORE PUBLISHING
1. Confirm the policy statements match your bot's actual code and data handling.
2. The current privacy text says the bot operator reports no permanent storage of bot pairing/user data; temporary runtime data may clear on restart. Do not claim this if your code or hosting setup behaves differently.
3. Check whether the bot stores command logs, analytics, backups, or data in files/database. Update the Privacy Policy if it does.
4. Confirm the Discord support invite https://discord.gg/nomens is valid and does not expire.
5. Consider adding a monitored contact method if users need privacy requests.

GITHUB PAGES STEPS
1. Sign in at https://github.com/ and create a new PUBLIC repository named: love-link-legal
2. Upload all four files from this folder to the repository root.
3. Open repository Settings > Pages.
4. Under "Build and deployment", choose "Deploy from a branch".
5. Choose branch "main" and folder "/ (root)", then Save.
6. Wait for GitHub Pages to publish. The site URL will look like:
   https://YOUR-GITHUB-USERNAME.github.io/love-link-legal/
7. Your legal URLs will be:
   https://YOUR-GITHUB-USERNAME.github.io/love-link-legal/terms.html
   https://YOUR-GITHUB-USERNAME.github.io/love-link-legal/privacy.html

DISCORD DEVELOPER PORTAL
1. Open https://discord.com/developers/applications
2. Select your Love Link application.
3. Open General Information.
4. Paste the Terms URL into Terms of Service URL.
5. Paste the Privacy URL into Privacy Policy URL.
6. Save changes.

Note: GitHub Pages publishes a static website. It does not host your Discord bot.
